df1 <- read.csv('problem1.csv')
View(df1)
x <- df1[,'x']
y <- df1[,'y']
plot(x,y)
m <- nls(y~ a* sin(x + b))
cor(y,predict(m))
lines(x,predict(m),lty=2,col="red",lwd=3)


plot(y,x,col = "blue",main = "Height & Weight Regression",
     abline(lm(x~y)),cex = 1.3,pch = 16,xlab = "x axis ",ylab = "y axis")